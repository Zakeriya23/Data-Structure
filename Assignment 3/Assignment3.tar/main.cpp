//Zakeriya Muhumed || CS163 || Assignemnt 3
/******************************************************************************
# Author:           Zakeriya Muhumed
# Assignment:       A03 (CS163)
# Date:             Feb 16, 2022
# Sources:          Assignment 3 instruction
#******************************************************************************/
#include "table.h"
#include "hero.h"

using namespace std;
int main(){
    int choice;
    table user_table;

    while(choice != 7){
        cout<< "Pick 1-7 options" << endl;
        cout <<"\t1) Add a new character "<< endl;
        cout <<"\t2) load information from external file " << endl;
        cout <<"\t3) Retrieve data" << endl;
        cout <<"\t4) Display ALL" << endl;
        cout <<"\t5) Display name " << endl;
        cout <<"\t6) Remove" <<endl;
        cout <<"\t7) Quit";
        cout <<"\n\t\t--->";
        cin >> choice; 
        cin.ignore();	

        while((choice < 1 && choice > 7) || (!cin)){
            cout <<"\n\t\t--->";
            cin>> choice;
            cin.ignore();
        }
        switch(choice){
            case 1:{//Add a new character from client

                char * inname= new char[100];
                char * inpower= new char[100];
                char * inspecies= new char[100];
                char * inbio = new char[100];

                cout <<"\t\nName of the hero: ";
                cin.get(inname,100, '\n');
                cin.ignore(100, '\n');


                cout <<"\t\nPower of this hero: ";
                cin.get(inpower, '\n');
                cin.ignore(100, '\n');

                cout <<"\t\nSpecies of the hero: ";
                cin.get(inspecies, '\n');
                cin.ignore(100, '\n');


                cout <<"\t\nDescription of hero: ";
                cin.get(inbio, '\n');
                cin.ignore(100, '\n');
                
                node* hero= new node;
                hero -> create_node(inname, inpower, inspecies, inbio);
                if(user_table.insert(inname, hero)==1){
                    cout << "Insert successfull!! " << endl;
                }
                else{
                    cout <<"Unsuccessfull insert!! " << endl;
                }

                delete [] inname;
                delete [] inpower;
                delete [] inspecies;
                delete [] inbio;
                delete hero;
                hero=nullptr;
                }break;
            case 2:{//Load from external files

                if(user_table.load()==0){
                    cout << "\nLoad unsuccessful" << endl;
                }
                else {
                    cout << " Load Successful" << endl;
                }

                break;}
            case 3:{//Retrieve data
                char * inname= new char[100];
                node **found = new node *[100];
                for(int i=0; i<100; i++){
                    found[i] = nullptr;
                }

                cout <<"\t\nEnter the character name you would like to retrieve: ";
                cin.get(inname,100, '\n');
                cin.ignore(100, '\n');


                if(user_table.retrieve(inname,found)==1){
                    cout << "Retrieve successfull!!!" <<endl;
                }
                else{
                    cout << "Retrieve Unsuccessfull!!!"<< endl;
                }
                for(int i=0; i<100; i++){
                    delete found[i];
                }
                delete [] inname;
                inname = nullptr;

                }break;
            case 4:{//Display table
                if(user_table.display_table()== 0){
                    cout << "Display unsuccessful"<< endl;
                }
                else {
                    cout << " Display Successful" << endl;
                }

                }break;
            case 5:{//Display specific name
                char * inname= new char[100];

                cout <<"\t\nEnter the character name you would like to display: ";
                cin.get(inname,100, '\n');
                cin.ignore(100, '\n');

                if(user_table.display_name(inname)== 0){
                    cout << "Display name unsuccessful"<< endl;
                }
                else {
                    cout << " Display Successful" << endl;
                }
                delete [] inname;
                inname = nullptr;
                }break;
            case 6:{//Remove
                char * inname= new char[100];

                cout <<"\t\nEnter the character name you would like remove: ";
                cin.get(inname,100, '\n');
                cin.ignore(100, '\n');
                if(user_table.remove(inname)==1){
                    cout << "Remove successfull!!!" <<endl;
                }
                else{
                    cout << "Remove Unsuccessfull!!!"<< endl;
                }
                delete [] inname;
                inname = nullptr;
                }break;
            case 7:{//QUIT
                cout << "Thank you for using this program" << endl;
                }break;
        }
    }

    return 0;
}
