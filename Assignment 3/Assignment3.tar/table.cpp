//Zakeriya Muhumed || CS163 || Assignemnt 3

#include "table.h"

using namespace std;
table::table(){
    hash_table = new node * [SIZE];
    for(int i = 0; i< SIZE; ++i){
        hash_table[i]= nullptr;
    }
}
table:: ~table(){
    for(int i = 0; i< SIZE; ++i){
        if(hash_table[i]){
            delete hash_table[i];
            hash_table[i] = nullptr;
        }
    }
    delete [] hash_table;
    hash_table = NULL;
}

int table::hash_function(char *key) const{

    int index=1;
    int size = strlen(key);

    for(int i= 0; i< size; ++i){
        index *= key[i];
    }
    int keyVal = index % size;
    return keyVal; 
}

int table::insert(char *inname,node * hero){
    if(!inname){
        return -1;
    }
    int index = hash_function(inname);
    if(!hash_table[index]){
        hash_table[index] = new node;
        hash_table[index]->copy_node(hero);
        return 1;
    }
    else{
        node * temp = hash_table[index];
        while(temp->next){
            temp = temp->next;
        }
        temp->next = new node;
        temp->next->copy_node(hero);
    }
    return 1;
}


int table::retrieve(char * title_to_find, node **& found){
    int key= hash_function(title_to_find);
    node * temp = hash_table[key];
    int count = 0;
    for(int i=0;i<23;i++){
        if(hash_table[i]){
            while(temp){

                if(temp ->compare(title_to_find)){
                    found[count]=new node;
                    found[count]->copy_node(temp);
                    count++;
                    return 1;
                }
                temp = temp->next;
            }
            delete temp;
            temp = nullptr;
        }
    }
    return 0;
}
int table:: load(){
    ifstream infile;

    int count =0; 
    infile.open(out);
    if(!infile){
        cout<<"Text file not found!!"<<endl;
        return -1;
    }
    if(infile){
        cout <<"\nFile opened" <<endl;
        while(!infile.eof() && count < SIZE){
            char * inname = new char[1000];
            char * inpower= new char[1000];
            char * inspecies= new char[1000];
            char * inbio= new char[1000];

            infile.get(inname,1000,'|');
            infile.ignore(1000,'|');
            infile.get(inpower,1000, '|');
            infile.ignore(1000,'|');
            infile.get(inspecies,1000,'|');
            infile.ignore(1000,'|');
            infile.get(inbio,1000,';');
            infile.ignore(1000,';');

            node * hero= new node;

            hero->create_node(inname, inpower, inspecies, inbio);
            insert(inname, hero);

            ++count;
            delete [] inname;
            delete [] inpower;
            delete [] inspecies;
            delete [] inbio;
        }
    }
    infile.close();
    return 1;
}
int table:: display_table(){
    int size = SIZE;
    int count= 0;
    for(int i = 0; i < size; ++i){
        if(hash_table[i]){
            node *current= hash_table[i];
            while(current){
                current->display();
                cout << endl;
                ++count;
                current=current->next;
            }
            delete current;
            current = nullptr;
        }
    }
    if(count >0){
        return 1;
    }
    return 0;
}
int table::display_name(char *inname){
    if (!inname) return 0;
    int count = 0;
    int index = hash_function(inname);
    node * temp= hash_table[index];
    while (temp){
        if(temp->compare(inname) == 0){
            temp -> display();
            count++;
        }
        temp = temp -> next;
    }
    return count;
} 

int table::remove(char *inname){
    if(!inname){
        return -1;
    }
    int index = hash_function(inname);
    if(!hash_table[index]){
        return 0;
    }
    return remove(hash_table[index],inname);

}

int table::remove(node *& deleting, char * inname){

    if (!deleting){
        return 1;
    } 
    if(deleting-> compare(inname)){
        node * current = deleting -> next;
        deleting -> next = nullptr;
        delete deleting;
        deleting = current;
        return remove(deleting, inname);
    }
    return remove(deleting->next, inname);
}


