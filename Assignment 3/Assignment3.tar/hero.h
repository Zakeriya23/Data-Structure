//Zakeriya Muhumed || CS163 || Assignemnt 3 

#ifndef node_h
#define node_h

#include <cstring>
#include <cctype>
#include <iostream>
#include <cstdlib>

class node
{
    public:

        node();
        ~node();

        int create_node(char *name, char * power, char *species, char * bio);
        bool compare(char *inname);
        int display();
        int copy_node(node * hero);
        node * next; 
    private:
        char * name;
        char * power;
        char * species;
        char * bio;
};
#endif

