//Zakeriya Muhumed || CS163 || Assignemnt 3
#ifndef table_h
#define table_h

#include "hero.h"

#include <cstring>
#include <cctype>
#include <iostream>
#include <fstream>
#include <cmath>

const char out[]="hero.txt";
const int SIZE = 41;

class table{
    public:
        table();   
        ~table();
        int insert(char *inname, node * hero);
        int load();
        int remove(char *inname);
        int remove(node *& deleting, char * inname);
        int retrieve(char * title_to_find, node **& found);
        int hash_function(char *key) const;
        int display_table();
        int display_name(char *inname);
    private:
        node ** hash_table; 
};
#endif
