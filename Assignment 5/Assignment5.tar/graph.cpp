//Zakeriya Muhumed || CS163 || Assignemnt 5

#include "data.h"
using namespace std;

//Constructor
table::table(int size){

    adjacency_list = new vertex[size];
    for(int i=0; i<size; i++){
        adjacency_list[i].head = nullptr;
        adjacency_list[i].data = "NULL";
    }
    list_size = size;

}
//Destructor
table::~table(){
    int size = 5;
    for(int i = 0; i < size; ++i){
        while(adjacency_list[i].head){
            node * temp = adjacency_list[i].head->next;
            delete adjacency_list[i].head;
            adjacency_list[i].head = temp;
        }
    }
    delete [] adjacency_list;
}

//Find a location in the graph
int table::find(string key_value){
    int position;

    for(int i = 0; i < list_size; ++i){

        if(adjacency_list[i].data == key_value){
            position = i;
            return position;
        }
    }
    return 0;
}

//Store the vertex at this location.
int table::insert_vertex(string concept){
    int key = find("NULL");
    adjacency_list[key].data = concept;
    return 1;
}

//Attach an edge to a vertex
int table::insert_edge(string current_vertex, string to_attach){
    //Attach this vertices edge to the specified vertex
    int curr = find(current_vertex);
    int att = find(to_attach);

    node * edge = new node;
    edge->adjacent = &adjacency_list[att];
    edge->next = adjacency_list[curr].head;
    adjacency_list[curr].head = edge;

    return 1;
}

//Display all vertices adjacent
int table::display_all(){
    for(int i = 0; i < 4; ++i){

        node * display = adjacency_list[i].head;

        cout << adjacency_list[i].data; 
        while(display){

            cout << "\t->"  << display->adjacent->data; 
            display = display->next; 

        }
    }
    return 1;
}
