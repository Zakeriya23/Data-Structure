//Zakeriya Muhumed || CS163 || Assignemnt 5
/******************************************************************************
# Author:           Zakeriya Muhumed
# Assignment:       A05 (CS163)
# Date:             March 10, 2022
# Sources:          Assignment 5 instruction
#******************************************************************************/
#include "data.h"

using namespace std;
int main(){
    int choice;
    table user_table;
    while(choice != 4){
        cout<< "Pick 1-4 options" << endl;
        cout <<"\t1) Add a step "<< endl;
        cout <<"\t2) Add ontop a step" << endl;
        cout <<"\t3) Display steps" << endl;
        cout <<"\t4) Quit";
        cout <<"\n\t\t--->";
        cin >> choice; 
        cin.ignore();	
        while((choice < 1 && choice > 4) || (!cin)){
            cout <<"\n\t\t--->";
            cin>> choice;
            cin.ignore();
        }
        switch(choice){
            case 1:{//Insert to vertex
                string concept;
                cout << "Enter the concept you want to add to vertex: "<< "\t-->";
                cin >> concept;

                if(user_table.insert_vertex(concept)==0){
                    cout << "\n\tUnsuccessfull insert!! " << endl;
                }
                else{
                    cout <<"\n\tsuccessfull insert!! " << endl;
                }

                }break;

            case 2:{//Insert an edge 
                string current;
                string attach;
                cout << "Enter the current vertex: "<< "\t-->";
                cin >> current;
                cout << "\n\nEnter the attach vertex: " << "\t-->";
                

                if(user_table.insert_edge(current,attach)==0)cout << "\tInsert edge unsuccessful" << endl;
                    cout << "\tInsert edge Successful" << endl;

                break;}

            case 3:{//Display Alll 
                if(user_table.display_all()==1){
                    cout << "\n\tDisplay all successfull!!!" <<endl;
                }
                else{
                    cout << "Display Unsuccessfull!!!"<< endl << endl;
                }
                }break;
            case 4:{//QUIT
                cout << "\nThank you for using this program" << endl;
                }break;
        }
    }
    return 0;
}
