//Zakeriya Muhumed || CS163 || Assignemnt 5
#include <iostream>
#include <string>
#include <cstring>
#include <iomanip>
using namespace std;
struct vertex{
   string data;  
   struct node * head;        
  };
 
 struct node{
   vertex * adjacent;     
   node * next;
 };

 class table{
    public:
            table(int size= 5);      
            ~table();   

            int insert_vertex(string concept);  
            int insert_edge(string current, string to_attach);
            int display_all();
            int find(string key);

    private:
            vertex * adjacency_list;
            int list_size = 5;
 
 };
